var proxy_domains = require("./proxy_domains");

var domains = {};

var proxy_domains_domains = proxy_domains.domains;

for(i in proxy_domains_domains){
    domains[proxy_domains_domains[i]] = 1;
}

var proxy = "__PROXY__";

var direct = '__DIRECT__';

var hasOwnProperty = Object.hasOwnProperty;

function FindProxyForURL(url, host) {
    var suffix;
    var pos = host.lastIndexOf('.');
    pos = host.lastIndexOf('.', pos - 1);
    while(1) {
        if (pos <= 0) {
            if (hasOwnProperty.call(domains, host)) {
                return proxy;
            } else {
                return direct;
            }
        }
        suffix = host.substring(pos + 1);
        if (hasOwnProperty.call(domains, suffix)) {
            return proxy;
        }
        pos = host.lastIndexOf('.', pos - 1);
    }
}

exports.FindProxyForURL = FindProxyForURL;
exports.__name__ = "shadowsocks";
