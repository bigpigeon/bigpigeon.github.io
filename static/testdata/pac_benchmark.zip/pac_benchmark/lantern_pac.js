var proxy_domains = require("./proxy_domains");
var domains = proxy_domains.domains.slice();

for(i in domains) {
    domains[i] = domains[i].split(/\./).join("\\.");
}

var proxyDomainsRegx = new RegExp("(" + domains.join("|") + ")$", "i");

var proxy = "__PROXY__";

var direct = '__DIRECT__';

function FindProxyForURL(url, host) {
    if( host == "localhost" ||
        host == "127.0.0.1") {
        return direct;
    }
    
    if (proxyDomainsRegx.exec(host)) {
        return proxy;
    }
    
    return direct;
}

exports.FindProxyForURL = FindProxyForURL;
exports.__name__ = "lantern";