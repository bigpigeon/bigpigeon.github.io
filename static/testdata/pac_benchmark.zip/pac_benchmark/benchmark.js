var assert = require("assert");
var util = require("util");
var process = require("process")
var p_shadowsocks = require("./shadowsocks_pac");
var p_lantern = require("./lantern_pac");
var p_own = require("./own_pac");

var pacs = [p_shadowsocks, p_lantern, p_own];

var count = Number(process.argv[2]);

var proxy_domain_two_node = "littlebigdetails.com";
var no_proxy_domain_two_node = "baidu.com";

var proxy_domain_three_node = "weigegebyc.dreamhosters.com";
var no_proxy_domain_three_node = "www.baidu.com";

var proxy_domain_four_node = "exec.weigegebyc.dreamhosters.com";
var no_proxy_domain_four_node = "g.pan.baidu.com";

var proxy = "__PROXY__";
var direct = '__DIRECT__';

for(var i = 0; i != pacs.length; i++)
{
    var pac = pacs[i];

    var result = pac.FindProxyForURL(proxy_domain_two_node, proxy_domain_two_node);
    assert.strictEqual(result, proxy, util.format("%s===%s by %s", result, proxy, pac.__name__));
    var result = pac.FindProxyForURL(no_proxy_domain_two_node, no_proxy_domain_two_node);
    assert.strictEqual(result, direct, util.format("%s===%s by %s", result, direct, pac.__name__));

    var result = pac.FindProxyForURL(proxy_domain_three_node, proxy_domain_three_node);
    assert.strictEqual(result, proxy, util.format("%s===%s by %s", result, proxy, pac.__name__));
    var result = pac.FindProxyForURL(no_proxy_domain_three_node, no_proxy_domain_three_node);
    assert.strictEqual(result, direct, util.format("%s===%s by %s", result, direct, pac.__name__));

    var result = pac.FindProxyForURL(proxy_domain_four_node, proxy_domain_four_node);
    assert.strictEqual(result, proxy, util.format("%s===%s by %s", result, proxy, pac.__name__));
    var result = pac.FindProxyForURL(no_proxy_domain_four_node, no_proxy_domain_four_node);
    assert.strictEqual(result, direct, util.format("%s===%s by %s", result, direct, pac.__name__));
}

for (var i = 0; i != pacs.length; i++)
{
    var pac = pacs[i];
    console.log(util.format("       %s benchmark       ", pac.__name__))

    var start = new Date();
    for(var n = count; n > 0; n--) {
    	pac.FindProxyForURL(proxy_domain_two_node, proxy_domain_two_node);
    }
    var end = new Date();
    console.log("proxy_domain_two_node result " + (end - start) + "ms");

    var start = new Date();
    for(var n = count; n > 0; n--) {
    	pac.FindProxyForURL(no_proxy_domain_two_node, no_proxy_domain_two_node);
    }
    var end = new Date();
    console.log("no_proxy_domain_two_node result " + (end - start) + "ms");

    var start = new Date();
    for(var n = count; n > 0; n--) {
    	pac.FindProxyForURL(proxy_domain_three_node, proxy_domain_three_node);
    }
    var end = new Date();
    console.log("proxy_domain_three_node result " + (end - start) + "ms");

    var start = new Date();
    for(var n = count; n > 0; n--) {
    	pac.FindProxyForURL(no_proxy_domain_three_node, no_proxy_domain_three_node);
    }
    var end = new Date();
    console.log("no_proxy_domain_three_node result " + (end - start) + "ms");

    var start = new Date();
    for(var n = count; n > 0; n--) {
    	pac.FindProxyForURL(proxy_domain_four_node, proxy_domain_four_node);
    }
    var end = new Date();
    console.log("proxy_domain_four_node result " + (end - start) + "ms");

    var start = new Date();
    for(var n = count; n > 0; n--) {
    	pac.FindProxyForURL(no_proxy_domain_four_node, no_proxy_domain_four_node);
    }
    var end = new Date();
    console.log("no_proxy_domain_four_node result " + (end - start) + "ms");

}