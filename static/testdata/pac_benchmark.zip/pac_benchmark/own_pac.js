var proxy_domains = require("./proxy_domains");
var domains = proxy_domains.domains;
domain_dict = {};

for(var i = 0; i < domains.length; i++){
    if(domains[i].endsWith(".")){
        domains[i] = domains[i].slice(0, -1)
    }
    var url_list = domains[i].split('.');

    for(var j = url_list.length,domain_node = domain_dict; j > 0; j--){
        var node_name = url_list[j-1];
        if (!domain_node.hasOwnProperty(node_name)){
            if (j === 1){
                domain_node[node_name] = true;
                break;
            } else {
                domain_node[node_name] = {};
            }
        } else if(domain_node[node_name] === true) {
            break;
        }
        domain_node = domain_node[node_name];
    }
}



var proxy = "__PROXY__";

var direct = '__DIRECT__';

function FindProxyForURL(url, host) {
    if( host == "localhost" ||
        host == "127.0.0.1") {
        return direct;
    }
    var host_list = host.split('.')
    var domain_node = domain_dict
    for(var i = host_list.length; i > 0; i--){
        var node_name = host_list[i-1]
        if (domain_node.hasOwnProperty(node_name)){
            if(domain_node[node_name] === true){
                return proxy;
            } else {
                domain_node = domain_node[node_name]
            }

        }
        else {
            return direct;
        }
    }
    return direct;
}

exports.FindProxyForURL = FindProxyForURL;
exports.__name__ = "bigpigeon_pac";